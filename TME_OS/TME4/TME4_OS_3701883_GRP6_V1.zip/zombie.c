// Fichier zombie.c
// Contient le main du programme qui éxécute le processus zombie durant 30 secondes
// Fait par Sharane K.Murali 3701883 Groupe 6 

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <sys/time.h>

int main() {
    pid_t p;
    p = fork();

    if(p == 0){ 
        exit(0);
    } 
    else { 
        sleep(30);
        wait(NULL);
    }
    return 0;
}
